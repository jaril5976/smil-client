export default () => {
  return false;
	// return (typeof window === 'undefined')
}