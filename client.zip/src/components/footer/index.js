import React from 'react';
import { Link } from "react-router-dom";

function Footer() {
  return (
    <h3>This is Footer Component</h3>
  );
}

export default Footer;
